import Home from './pages/Home'
import LoginPage from './pages/LoginPage'
import { BrowserRouter, Routes, Route } from "react-router-dom"
import ProtectedRoute from './components/ProtectedRoute'
import { LocationProvider } from './contexts/LocationContext'

function App() {


  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='' element={
            <ProtectedRoute>
              <LocationProvider>
                <Home />
              </LocationProvider>
            </ProtectedRoute>
          } />
          <Route path='/login' element={<LoginPage />} />
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
