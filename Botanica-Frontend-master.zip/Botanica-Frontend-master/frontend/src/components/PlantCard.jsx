/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import { IoMdSunny, IoIosCheckmarkCircle } from "react-icons/io";
import { FiDroplet } from "react-icons/fi";
import { FaTrash } from "react-icons/fa";
import { IoTrashOutline } from "react-icons/io5";
import { LuThumbsUp } from "react-icons/lu";
import { CiTempHigh } from "react-icons/ci";
import { MdOutlineSevereCold } from "react-icons/md";
import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion"
import api from "../api";
import LineChart from "./LineChart";

const capitalizeFirstLetter = (str) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
}
const round = (x) => Math.floor(x * 10) / 10
const formatDate = (dateString, format) => {
    /* 
    Takes: 
        dateString: string of the form "YYYY-MM-DDTHH:mm:ss"
        format: string that describes the format of the result
    Returns: 
        string where every occurence of YYYY, MM, DD, HH, mm, ss in format will be replaced by its value in dateString
    */
    const date = new Date(dateString);

    const year = date.getUTCFullYear();
    const month = String(date.getUTCMonth() + 1).padStart(2, '0');
    const day = String(date.getUTCDate()).padStart(2, '0');
    const hour = String(date.getUTCHours()).padStart(2, '0');
    const minute = String(date.getUTCMinutes()).padStart(2, '0');
    const second = String(date.getUTCSeconds()).padStart(2, '0');

    return format.replace("YYYY", year)
        .replace("MM", month)
        .replace("DD", day)
        .replace("HH", hour)
        .replace("mm", minute)
        .replace("ss", second);
}
const day_difference = (d1, d2) => {
    const date1 = new Date(d1)
    const date2 = new Date(d2)
    return Math.floor((date1 - date2) / 86400000)
}

const yield_time = (dateString, days_to_yield) => {
    /* 
    Takes: 
        dateString: string of date planted
        days_to_yield: expected time for crop to yield
    Returns: 
        days until plant planted at this date yields
    */
    const yieldDate = new Date((new Date(dateString)).getTime() + days_to_yield * 86400000)
    const today = new Date()
    return Math.max(0, Math.floor((yieldDate - today) / 86400000))
}

// Yield: Kg/m^2
// Pruning Month: 
// Growth Rate: 

function PlantCard({
    userPlants, setUserPlants,
    crop, id,
    lat, lon,
    last_watered, time_planted,
    prediction_probability
}) {

    const [maxForecastedTemp, setMaxForecastedTemp] = useState(crop.max_hardiness);
    const [minForecastedTemp, setMinForecastedTemp] = useState(crop.min_hardiness);

    useEffect(() => {
        const getWeather = async () => {
            const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&daily=temperature_2m_max,temperature_2m_min&timezone=auto`)

            if (response.ok) {
                const jsonResponse = await response.json();
                console.log(jsonResponse)
                setMaxForecastedTemp(Math.max(...jsonResponse["daily"]["temperature_2m_max"]))
                setMinForecastedTemp(Math.min(...jsonResponse["daily"]["temperature_2m_min"]))
            }
        }

        getWeather()
    }, [])

    const wateringFrequencyToDays = {
        "frequent": 2,
        "medium": 4,
        "low": 7,
        "none": 365
    }

    const [showDetail, setShowDetail] = useState(false)
    const yieldsIn = yield_time(time_planted, crop.days_to_yield)
    const last_watering = new Date(last_watered), today = new Date()
    const days_since_watering = day_difference(today, last_watering)
    const next_watering = new Date(last_watering); next_watering.setDate(next_watering.getDate() + wateringFrequencyToDays[crop.watering])
    const days_until_watering = day_difference(next_watering, today)
    const [landArea, setLandArea] = useState("")


    const [needsWatering, setNeedsWatering] = useState(days_since_watering >= wateringFrequencyToDays[crop.watering])
    const handlePlantWater = (e) => {
        e.preventDefault()
        e.stopPropagation() // so not to expand the card
        const water = async () => {
            // Send an update to backend to water
            const response = await api.patch(`/crops/${id}/update/`)
            if (response.status == 200) {
                setUserPlants(userPlants.map((e) => e.id == id ? response.data : e))
                setNeedsWatering(false);
            } else {
                console.log("Something vary bad has happened to your crop")
            }
        }
        water()
    }

    async function handlePlantDelete() {
        const response = await api.delete(`/crops/${id}/delete/`)
        if (response.status == 204) {
            setUserPlants(prev => prev.filter((elem) => elem["id"] != id))
            setShowDetail(false)
        } else {
            alert("Something went wrong")
        }
    }

    return (
        <div
            className="w-full z-50 max-w-110 h-auto flex flex-col items-center justify-center px-3">
            {/* First Layer (image, name, watering) */}
            <div className="flex w-full flex-row h-20 justify-around items-center cursor-pointer"
                onClick={() => {
                    setShowDetail(!showDetail)
                }}
            >
                {/* Image */}
                <div className="w-1/5 min-w-20 h-full flex items-center justify-center">
                    <div className="w-full h-full flex items-center justify-center">
                        <img className="w-7/10 h-7/10" src={crop.image_url} alt="" />
                    </div>
                </div>

                {/* Name, watering, sun */}
                <div className="w-3/5 h-full px-3">
                    <div className="h-full flex flex-col justify-center">
                        {/* Name and date planted */}
                        <div className="flex flex-col pb-1">
                            <p className="text-lg text-white">{capitalizeFirstLetter(crop.name)}</p>
                            <p className="text-[0.7rem] text-neutral-500">Planted {formatDate(time_planted, "DD/MM/YYYY at HH:mm")}</p>
                        </div>
                        <div className="flex justify-between items-center">
                            {/* Watering and Sun */}
                            <div className="flex">
                                <div className="w-20 flex flex-row gap-1.5 items-center mr-4">
                                    <FiDroplet className="text-blue-500" />
                                    <p className="text-sm text-slate-100">{capitalizeFirstLetter(crop.watering)}</p>
                                </div>
                                <div className="w-14 flex flex-row gap-1.5 items-center">
                                    <IoMdSunny className="text-yellow-500" />
                                    <p className="text-sm text-slate-100">{capitalizeFirstLetter(crop.sunlight.split("_")[0])}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Status */}
                <div className="w-1/5 h-full flex items-center justify-center">
                    {needsWatering ?
                        <div className="rounded-full border-2 border-yellow-400 bg-yellow-500/[0.18] w-1/2 h-1/2 flex items-center justify-center">
                            <FiDroplet className="text-xl text-yellow-500"></FiDroplet>
                        </div>
                        :
                        maxForecastedTemp > crop.max_hardiness ?
                            <div className="rounded-full border-2 border-red-400 bg-red-500/[0.18] w-1/2 h-1/2 flex items-center justify-center">
                                <CiTempHigh className="text-xl text-red-500"></CiTempHigh>
                            </div>
                            :
                            minForecastedTemp < crop.min_hardiness ?
                                <div className="rounded-full border-2 border-blue-400 bg-blue-500/[0.18] w-1/2 h-1/2 flex items-center justify-center">
                                    <MdOutlineSevereCold className="text-xl text-blue-500"></MdOutlineSevereCold>
                                </div>
                                :
                                <div className="rounded-full border-2 border-green-400 bg-green-500/[0.18] w-1/2 h-1/2 flex items-center justify-center">
                                    <LuThumbsUp className="text-xl text-green-500"></LuThumbsUp>
                                </div>

                    }
                </div>
            </div>
            {/* Second Layer (extra data, yield time) */}
            <AnimatePresence>
                {showDetail &&
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3, ease: "easeInOut" }}
                        className="w-full h-auto flex flex-col gap-2 justify-between px-3 text-sm text-slate-100 items-center"
                    >
                        <div className="flex-row w-full flex h-auto"
                            onClick={() => {
                                setShowDetail(!showDetail)
                            }}
                        >
                            <div className="w-1/2 flex flex-col justify-center gap-2 py-2 px-1">
                                <p><span className="font-semibold">Placement:</span> {crop.indoor ? "Indoors" : "Outdoors"}</p>
                                <p><span className="font-semibold">Cycle:</span> {capitalizeFirstLetter(crop.cycle)}</p>
                                <p><span className="font-semibold">Hardiness:</span> {crop.min_hardiness}-{crop.max_hardiness}</p>
                            </div>
                            <div className="w-1/2 flex flex-col justify-center gap-2 px-1 py-2">
                                <p><span className="font-semibold">Next Watering:</span> {days_until_watering == 1 ? "1 day" : days_until_watering > 0 ? `${days_until_watering} days` : "Now"}</p>
                                <p><span className="font-semibold">Watering vol:</span> {crop.watering_avg_volume_requirement} L/m<sup>2</sup></p>
                                <p><span className="font-semibold">Yields in:</span> {yieldsIn == 1 ? "1 day" : `${yieldsIn} days`}</p>
                            </div>
                        </div>

                        {/* Detailed Alerts about weather */}
                        {(maxForecastedTemp > crop.max_hardiness || minForecastedTemp < crop.min_hardiness) &&
                            <>
                                <div className="w-1/2 max-w-100 border border-white/[0.1] my-2" />
                                <div className="w-full flex flex-col gap-2">
                                    {maxForecastedTemp > crop.max_hardiness &&
                                        <p className=""><span>•</span>The maximum temperature in the coming 7 days will be <span className="font-semibold">{maxForecastedTemp}°C</span>. {capitalizeFirstLetter(crop.name)} can only handle <span className="font-semibold">{crop.max_hardiness}°C</span>.</p>
                                    }
                                    {minForecastedTemp < crop.min_hardiness &&
                                        <p className=""><span>•</span>The minimum temperature in the coming 7 days will be <span className="font-semibold">{minForecastedTemp}°C</span>. {capitalizeFirstLetter(crop.name)} can only handle <span className="font-semibold">{crop.min_hardiness}°C</span>.</p>
                                    }
                                </div>
                                <div className="w-1/2 max-w-100 border border-white/[0.1] my-2" />
                            </>
                        }
                        {/* Graph */}
                        <div className="w-full h-50">
                            <LineChart cropName={capitalizeFirstLetter(crop.name)} prices={[4.25, 4.40, 4.60, 4.80, 5.10, 5.50, 5.75, 5.60, 5.30, 5.00, 4.75, 4.50]} />
                        </div>
                        {/* Expected Yield */}
                        <div className="w-full flex flex-row justify-between">
                            <div className="w-1/2">
                                <input
                                    type="number"
                                    placeholder="Enter Land Area in m²"
                                    className="input focus:bg-transparent input-ghost border-white/[0.1] border-2 rounded-lg mr-3"
                                    min="0"
                                    max="100000"
                                    value={landArea}
                                    onChange={(e) => {
                                        // to prevent symbols like +,-,e,E or 
                                        if (!(e.target.value || e.target.value < 10)) e.preventDefault()
                                        // to enforce limits when typing: max is only enforced when using arrows
                                        else if (e.target.value <= 100000) setLandArea(e.target.value)
                                        else e.preventDefault()
                                        console.log(e.target.value)
                                    }}
                                />
                            </div>
                            <div className="w-1/2 flex flex-row justify-center items-center">
                                <p className="text-md"><span className="font-semibold">Expected Yield: </span>{landArea ? round(landArea * crop.crop_yield * (prediction_probability / 100)) : 0} kg</p>
                            </div>
                        </div>
                        <div className="w-full flex flex-row justify-between gap-5 items-center h-10">
                            <button
                                className="border-2 border-red-400 hover:bg-red-500/[0.1] hover:border-red-500 transition duration-200 cursor-pointer rounded-lg w-1/2 h-full flex justify-center items-center"
                                onClick={handlePlantDelete}
                            >
                                <IoTrashOutline className="text-xl text-red-500"></IoTrashOutline>
                            </button>
                            <div
                                className="border-2 hover:bg-blue-400/[0.1] hover:border-blue-300 transition duration-200 cursor-pointer w-1/2 h-full rounded-lg flex justify-center items-center"
                                onClick={handlePlantWater}
                            >
                                <FiDroplet className="text-blue-500 text-xl"></FiDroplet>
                            </div>
                        </div>

                    </motion.div>
                }
            </AnimatePresence>
        </div>
    )
}

export default PlantCard