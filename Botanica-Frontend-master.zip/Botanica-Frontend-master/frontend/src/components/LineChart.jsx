import React from 'react';
import { Line } from 'react-chartjs-2';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend
} from 'chart.js';

// Register ChartJS components
ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    Title,
    Tooltip,
    Legend
);

const LineChart = ({ cropName, prices }) => {
    // Crop price data over the months
    const data = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        datasets: [
            {
                label: `${cropName} Prices`,
                data: prices,
                borderColor: 'rgb(70, 180, 86)',
                tension: 0.1,
                backgroundColor: 'rgba(70, 180, 86, 0.2)'
            }
        ]
    };

    // Chart configuration options
    const options = {
        responsive: true,
        plugins: {
            legend: {
                position: 'top',
            },
            title: {
                display: false,
                text: 'Crop Prices Throughout the Year'
            }
        },
        scales: {
            y: {
                beginAtZero: false,
                title: {
                    display: true,
                    text: 'Price per Bushel ($)'
                }
            }
        }
    };

    return (
        <div className="w-full max-w-2xl mx-auto p-4">
            <Line data={data} options={options} />
        </div>
    );
};

export default LineChart;