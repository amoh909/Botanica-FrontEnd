import { IoExitOutline } from "react-icons/io5";
import { useNavigate } from "react-router-dom";

function LogoutButton() {
    const navigate = useNavigate()
    function logout() {
        localStorage.clear()
        navigate("/login")
    }

    return <button className="w-auto cursor-pointer text-3xl mx-4" onClick={logout}>
        <IoExitOutline></IoExitOutline>
    </button>
}

export default LogoutButton