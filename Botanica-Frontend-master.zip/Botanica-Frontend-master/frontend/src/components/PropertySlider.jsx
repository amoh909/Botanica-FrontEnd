import Slider from '@mui/material/Slider';
/* eslint-disable react/prop-types */
const PropertySlider = ({
    name, unit, value,
    min, max, handleChange,
    off = false
}) => {
    return (
        <div
            className="w-full text-white"
        >
            <div
                className={`flex justify-between w-full transition duration-200 ${off ? "text-white/[0.3]" : ""}`}
            >
                <p>{name}</p>
                <p>{value} {unit}</p>
            </div>
            <Slider
                className = ""
                size = "small"
                min={min}
                max={max}
                value={value}
                onChange={handleChange}
                color="gray"
                valueLabelDisplay="auto"
                disabled = {off}
            />
        </div>

    )
}

export default PropertySlider