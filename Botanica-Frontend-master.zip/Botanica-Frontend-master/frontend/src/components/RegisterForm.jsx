import { useState } from "react"
import api from "../api"
import { useNavigate } from "react-router-dom"

function RegisterForm({setRegistering}) {
    const [usernameField, setUsernameField] = useState("")
    const [passwordField, setPasswordField] = useState("")
    const [passwordAgainField, setPasswordAgainField] = useState("")
    const [error, setError] = useState(null)
    const navigate = useNavigate()

    async function handleFormSubmit(e) {
        e.preventDefault()

        if (!usernameField || !passwordField || !passwordAgainField) {
            setError("All Fields are required")
            return
        }

        const response1 = await api.post("/auth/register/", { 
            username: usernameField, 
            password: passwordField,
            password2: passwordAgainField
        })

        if (response1.status == 201) {
            // now automatically log in the user
            const response2 = await api.post("/auth/login/", { 
                username: usernameField, 
                password: passwordField 
            })

            if (response2.status == 200) {
                localStorage.setItem("access", response2.data.access)
                localStorage.setItem("refresh", response2.data.refresh)
                localStorage.setItem("username", response2.data.username)
                localStorage.setItem("user_id", response2.data.user_id)
                navigate("/")
            } else {
                setError(response2.data.detail)
            }
        } else {
            setError(response1.data.detail)
        }

    }

    return (
        <>
            <form 
            method="POST" 
            className="flex flex-col bg-transparent rounded-2xl bg-slate-100/[0.08] border-white border shadow-2xl backdrop-blur-md drop-shadow-2xl justify-around items-center max-w-80 px-5">
                <div className="h-50 flex justify-center items-center">
                    <svg className="w-10 h-10 text-slate-100 text-9xl hover:rotate-90 transition-all duration-500" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M12 2c-.791 0-1.55.314-2.11.874l-.893.893a.985.985 0 0 1-.696.288H7.04A2.984 2.984 0 0 0 4.055 7.04v1.262a.986.986 0 0 1-.288.696l-.893.893a2.984 2.984 0 0 0 0 4.22l.893.893a.985.985 0 0 1 .288.696v1.262a2.984 2.984 0 0 0 2.984 2.984h1.262c.261 0 .512.104.696.288l.893.893a2.984 2.984 0 0 0 4.22 0l.893-.893a.985.985 0 0 1 .696-.288h1.262a2.984 2.984 0 0 0 2.984-2.984V15.7c0-.261.104-.512.288-.696l.893-.893a2.984 2.984 0 0 0 0-4.22l-.893-.893a.985.985 0 0 1-.288-.696V7.04a2.984 2.984 0 0 0-2.984-2.984h-1.262a.985.985 0 0 1-.696-.288l-.893-.893A2.984 2.984 0 0 0 12 2Zm3.683 7.73a1 1 0 1 0-1.414-1.413l-4.253 4.253-1.277-1.277a1 1 0 0 0-1.415 1.414l1.985 1.984a1 1 0 0 0 1.414 0l4.96-4.96Z" />
                    </svg>
                    <h1 className="text-white text-4xl text-left font-bold ml-4">
                        Start <br /> Today!
                    </h1>
                </div>
                {error &&
                    <p className="w-full px-5 pb-3 text-red-600 font-semibold">• {error}</p>
                }
                <div className="h-2/5 flex flex-col justify-around items-center w-full mb-5">
                    <input className="focus:shadow-xl outline-none bg-white/[0.1] backdrop-blur-lg h-8 w-64 p-2 placeholder-white rounded-lg text-white mb-3" placeholder="Username" type="text" name="username" required onChange={(e) => setUsernameField(e.target.value)} />
                    <input className="focus:shadow-xl outline-none bg-white/[0.1] backdrop-blur-lg h-8 w-64 p-2 placeholder-white rounded-lg text-white mb-3" placeholder="Password" type="password" name="password" required onChange={(e) => setPasswordField(e.target.value)} />
                    <input className="focus:shadow-xl outline-none bg-white/[0.1] backdrop-blur-lg h-8 w-64 p-2 placeholder-white rounded-lg text-white mb-3" placeholder="Password again" type="password" name="password-again" required onChange={(e) => setPasswordAgainField(e.target.value)} />
                    <button className="hover:shadow-xl mb-3 text-green-600 font-semibold bg-white p-2 w-1/2 rounded-xl transition-all duration-200 hover:shadow-2xl hover:bg-white/[0.1] hover:text-white border cursor-pointer" type="submit" onClick={handleFormSubmit}>Register</button>
                    <p className = "text-sm">Already have an account? 
                        <span
                        className = "pl-1 font-semibold hover:underline cursor-pointer"
                        onClick = {() => setRegistering(false)}
                        > 
                        Login here
                        </span>
                    </p>
                </div>
            </form>
        </>
    )
}

export default RegisterForm
