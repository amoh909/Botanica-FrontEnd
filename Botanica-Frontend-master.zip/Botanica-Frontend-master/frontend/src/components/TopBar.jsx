/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import { FaCloudRain } from "react-icons/fa6";
import LogoutButton from "./LogoutButton";
import { useEffect, useState } from "react";
import WeatherIcon from "./WeatherIcon";

function TopBar({
    longitude, latitude
}) {

    // Weather location will be based on user's current location only
    const [locationName, setLocationName] = useState("Hamra")
    const [weather, setWeather] = useState(null)
    const weatherCodeToCondition = {
        0: "clear_sky",
        1: "mainly_clear",
        2: "partly_cloudy",
        3: "overcast",
        45: "fog",
        48: "depositing_rime_fog",
        51: "light_drizzle",
        53: "moderate_drizzle",
        55: "heavy_drizzle",
        61: "light_rain",
        63: "moderate_rain",
        65: "heavy_rain",
        66: "light_freezing_rain",
        67: "heavy_freezing_rain",
        71: "light_snow",
        73: "moderate_snow",
        75: "heavy_snow",
        77: "snow_grains",
        80: "light_rain_shower",
        81: "moderate_rain_shower",
        82: "heavy_rain_shower",
        85: "light_snow_shower",
        86: "heavy_snow_shower",
        95: "thunderstorm",
        96: "thunderstorm_with_light_hail",
        99: "thunderstorm_with_heavy_hail"
    };

    useEffect(() => {
        const getLocation = async () => {
            const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${latitude}&lon=${longitude}`)
            if (!response.ok) {
                setLocationName(":(")
            } else {
                const jsonResponse = await response.json()
                setLocationName(jsonResponse.display_name.split(",")[0])
            }
        }
        const getWeatherData = async () => {
            const response = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current_weather=true&hourly=relative_humidity_2m`)
            if(response.ok){
                const jsonResponse = await response.json()
                // hourly.relative_humidity_2m is an array of humidity values at each hour of the day
                // starting at midnight, so just have to get the current hour and take that index
                setWeather({
                    condition: weatherCodeToCondition[jsonResponse.current_weather.weathercode],
                    temperature : jsonResponse.current_weather.temperature,
                    humidity : jsonResponse.hourly.relative_humidity_2m[new Date().getHours()]
                })
            }
        }
        getLocation()
        getWeatherData()
    }, [latitude, longitude])

    return <div className="sm:left-2 z-50 w-9/10 max-w-110 bg-neutral-950/[0.85] h-1/12 fixed mt-3 rounded-2xl flex flex-row justify-between items-center backdrop-blur-lg shadow-xl">
        {/* Weather */}
        {weather ? 
        <div className="w-auto min-w-1/3 h-full flex flex-row items-center">
            {/* Weather Icon */}
            <div className="px-5 h-full flex justify-center items-center w-16">
                <WeatherIcon condition = {weather.condition}/>
            </div>
            {/* Weather info */}
            <div className="pb-1">
                <p className="text-xl text-slate-100 ">{weather.temperature} C°</p>
                <p className="text-[0.7rem] text-slate-100">Humidity: {weather.humidity}%</p>
            </div>
        </div>
        :
        <div className="w-auto min-w-1/3 h-full flex flex-col justify-center pl-5">
            <p className = "text-white/[0.3]">Loading weather data . . .</p>
        </div>
        }
        <div className="flex justify-end w-auto min-w-2/5">
            {/* Location */}
            <div className="pb-1 w-full flex flex-col items-end">
                <p className="text-base text-right text-slate-100 font-semibold">{locationName}</p>
                <p className="text-[0.7rem] text-slate-100">{latitude.toFixed(4)}, {longitude.toFixed(4)}</p>
            </div>
            <LogoutButton />
        </div>

    </div>
}

export default TopBar