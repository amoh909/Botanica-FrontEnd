/* eslint-disable react/prop-types */
import PropertySlider from './PropertySlider'

const SliderContainer = ({ 
  soilAndWeatherProperties,
  ignoreNPK
}) => {

  return (
    <div
      className="w-full max-w-110 h-auto flex flex-col items-center justify-center py-3 px-6"
    >
      <PropertySlider
        name="Nitrogen"
        unit="cg/kg"
        value={soilAndWeatherProperties.N.value}
        min={0}
        max={250}
        handleChange={(e, value) => soilAndWeatherProperties.N.setter(value)}
        off = {ignoreNPK}
      />
      <PropertySlider
        name="Phosphorus"
        unit="cg/kg"
        value={soilAndWeatherProperties.P.value}
        min={0}
        max={250}
        handleChange={(e, value) => soilAndWeatherProperties.P.setter(value)}
        off = {ignoreNPK}
      />
      <PropertySlider
        name="Potassium"
        unit="cg/kg"
        value={soilAndWeatherProperties.K.value}
        min={0}
        max={250}
        handleChange={(e, value) => soilAndWeatherProperties.K.setter(value)}
        off = {ignoreNPK}
      />
      <PropertySlider
        name="Temperature"
        unit="C°"
        value={soilAndWeatherProperties.temp.value}
        min={-5}
        max={45}
        handleChange={(e, value) => soilAndWeatherProperties.temp.setter(value)}
      />
      <PropertySlider
        name="Humidity"
        unit="%"
        value={soilAndWeatherProperties.humid.value}
        min={0}
        max={100}
        handleChange={(e, value) => soilAndWeatherProperties.humid.setter(value)}
      />
      <PropertySlider
        name="pH"
        unit="log"
        value={soilAndWeatherProperties.PH.value}
        min={2}
        max={12}
        handleChange={(e, value) => soilAndWeatherProperties.PH.setter(value)}
      />
      <PropertySlider
        name="Rainfall"
        unit="cm"
        value={soilAndWeatherProperties.rain.value}
        min={0}
        max={500}
        handleChange={(e, value) => soilAndWeatherProperties.rain.setter(value)}
      />
    </div>
  )
}

export default SliderContainer