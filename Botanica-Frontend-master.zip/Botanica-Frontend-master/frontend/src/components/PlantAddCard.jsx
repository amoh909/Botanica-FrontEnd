/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
import { IoMdSunny, IoIosAdd } from "react-icons/io";
import { FiDroplet } from "react-icons/fi";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion"
import api from "../api";

const capitalizeFirstLetter = (str) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

const round = (x) => Math.floor(x * 10) / 10

function PlantAddCard({
    latitude,
    longitude,
    setUserPlants,
    probability, crop_name, crop
}) {

    async function handlePlantAdd() {
        console.log(latitude)
        const response = await api.post("/crops/", { "lat": latitude.toFixed(8), "lon": longitude.toFixed(8), "prediction_probability": probability, "crop_id": crop.id })
        if (response.status == 201) {
            setUserPlants(prev => [response.data, ...prev])
        } else {
            alert("Something went wrong")
        }
    }

    const textColor = (probability <= 25 ? 0 : probability <= 50 ? 1 : probability <= 75 ? 2 : 3)
    const colorMappings = {
        0: "text-red-500",
        1: "text-amber-500",
        2: "text-yellow-300",
        3: "text-green-500"
    }

    const [showDetail, setShowDetail] = useState(false)

    return <div onClick={() => setShowDetail(!showDetail)} className="w-full z-50 max-w-110 h-auto flex flex-col items-center justify-center px-3">
        <div className="w-full h-auto flex flex-row items-center justify-between px-2">
            <div className="flex w-full flex-row justify-between items-center ">
                {/* Name, Watering, Sun... */}
                <div className="w-auto flex flex-row justify-between items-center cursor-pointer">
                    {/* Name */}
                    <p className="pl-2 text-xl text-white">{capitalizeFirstLetter(crop.name)}</p>
                </div>
                <div className="flex gap-1">
                    <div className="flex justify-between items-center">
                        {/* Watering and Sun */}
                        <div className="flex">
                            <div className="w-auto max-w-22 flex flex-row gap-1.5 items-center mr-4">
                                <FiDroplet className="text-blue-500" />
                                <p className="text-sm text-slate-100">{capitalizeFirstLetter(crop.watering)}</p>
                            </div>
                            <div className="w-14 flex flex-row gap-1.5 items-center">
                                <IoMdSunny className="text-yellow-500" />
                                <p className="text-sm text-slate-100">{capitalizeFirstLetter(crop.sunlight.split("_")[0])}</p>
                            </div>
                        </div>
                    </div>
                    <div
                        className="flex justify-center items-center cursor-pointer text-white/[0.3] hover:text-white/[0.6] transition duration-200"
                        onClick={(e) => {
                            e.stopPropagation()
                            handlePlantAdd()
                        }}
                    >
                        <IoIosAdd
                            className="text-4xl"
                        />
                    </div>
                </div>
            </div>
        </div>
        <div className="w-full flex px-4 flex-row items-center justify-between">
            <div className="flex flex-col w-2/5">
                <p className="text-slate-100"><span className="font-semibold">Success: </span>
                    {round(probability)}%
                </p>
            </div>
            <progress className={`progress ${colorMappings[textColor]} w-3/5`} value={probability} max="100"></progress>
        </div>

        {/* Second Layer (extra data, yield time) */}
        <AnimatePresence>
            {showDetail &&
                <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3, ease: "easeInOut" }}
                    className="w-full h-auto flex flex-row justify-between px-3"
                >
                    <div className="flex-row w-full flex h-auto">
                        <div className="w-1/2 flex flex-col justify-center gap-2 py-2 px-1">
                            <p><span className="font-semibold">Placement:</span> {crop.indoor ? "Indoors" : "Outdoors"}</p>
                            <p><span className="font-semibold">Cycle:</span> {capitalizeFirstLetter(crop.cycle)}</p>
                        </div>
                        <div className="w-1/2 flex flex-col justify-center gap-2 py-2 px-1">
                            <p><span className="font-semibold">Watering vol:</span> {crop.watering_avg_volume_requirement} L/m<sup>2</sup></p>
                            <p><span className="font-semibold">Hardiness:</span> {crop.min_hardiness}-{crop.max_hardiness}</p>
                        </div>

                    </div>
                </motion.div>
            }
        </AnimatePresence>
    </div>
}

export default PlantAddCard