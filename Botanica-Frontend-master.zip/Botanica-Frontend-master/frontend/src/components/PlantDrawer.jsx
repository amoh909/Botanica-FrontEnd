/* eslint-disable react/prop-types */
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import PlantCard from "./PlantCard"
import { motion } from "framer-motion"
import { useState, useEffect } from "react";
import React from "react";
import { IoIosAdd, IoIosArrowRoundBack } from "react-icons/io";
import MinimizedPlantCard from "./MinimizedPlantCard";

function PlantDrawer({
    expanded, setExpanded,
    isSmallScreen,
    isAddingPlant, setAddingPlant,
    latitude,
    longitude,
    userPlants, setUserPlants,
    allPlants
}) {

    return <motion.div
        initial={{}}
        // This may not be great. Framer motion now controls the height instead of tailwind
        // This now shows a different number of cards depending on screen size
        animate={{ height: expanded ? "100%" : isSmallScreen ? "28%" : "75%" }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className={`sm:py-2 z-[108] sm:left-2 bottom-0 sm:bottom-2 sm:top-1/2 sm:-translate-y-1/2 fixed w-full max-w-110 ${expanded ? "h-screen" : "h-3/9"} flex flex-col bg-neutral-950/[0.85] rounded-t-2xl items-center backdrop-blur-lg sm:rounded-b-2xl shadow-xl`}>

        {/* Chevron */}
        <div
            onClick={() => {
                setAddingPlant(false)
                setExpanded(!expanded)
            }}
            className="sm:hidden chevron-button h-5 w-full flex items-center justify-center py-5 cursor-pointer"
        >
            {expanded ? <FaChevronDown className="text-2xl text-slate-100" /> : <FaChevronUp className="text-2xl text-slate-100" />}
        </div>
        {isAddingPlant ?
            <>
                <div
                    className="h-10 w-full flex items-center text-white/[0.3] hover:text-white/[0.6] transition duration-200 cursor-pointer"
                    onClick={() => setAddingPlant(false)}
                >
                    <div
                        className="h-10 w-10 flex justify-center items-center mx-2"
                    >
                        <IoIosArrowRoundBack
                            className="text-[2rem]"
                        />
                    </div>
                    <p>Back to my plants</p>
                </div>
            </>
            :
            <div
                className="min-h-10 w-full flex justify-center items-center"
            >
                <p className="font-semibold">My Plants</p>
            </div>
        }
        <div className="w-full border border-white/[0.1] mt-2"></div>
        <div className={`sm:overflow-y-scroll no-scrollbar w-full flex flex-col items-center ${expanded ? "overflow-y-scroll" : ""}`}>
            {isAddingPlant ?
                allPlants.map((plant, index) => (
                    <React.Fragment key={index} > {/* just so we can give the fragment a key */}
                        <MinimizedPlantCard
                            latitude={latitude}
                            longitude={longitude}
                            {...plant}
                            setUserPlants={setUserPlants}
                            setAddingPlant={setAddingPlant}
                        />
                        <div className="w-9/10 max-w-100 border border-white/[0.1]"></div>
                    </React.Fragment>
                ))
                :
                <>
                    {/* Plant Cards */}
                    {userPlants.length ?
                        <>
                        <div className="mb-2" />
                        {userPlants.map((plant, index) => (
                            <React.Fragment key={index} > {/* just so we can give the fragment a key */}
                                <PlantCard
                                    userPlants={userPlants}
                                    setUserPlants={setUserPlants}
                                    {...plant}
                                />
                                <div className="w-9/10 max-w-100 border border-white/[0.1] my-2" />
                            </React.Fragment>
                        ))}
                        </>
                        :
                        <>
                            {/* userPlants is empty */}
                            <div className="h-20 flex flex-col justify-center items-center text-white/[0.3]">
                                <p>You currently have nothing planted</p>
                                {(isSmallScreen && !expanded) &&
                                    <p>Expand the drawer to add a plant</p>
                                }
                            </div>
                            <div className="w-full max-w-110 border border-white/[0.1]" />
                        </>
                    }
                    <div
                        className="w-full z-50 max-w-110 h-auto flex flex-col items-center justify-center px-3 cursor-pointer"
                        onClick={() => setAddingPlant(true)}
                    >
                        <div className="flex w-full flex-row h-20 items-center text-white/[0.3] hover:text-white/[0.6] transition duration-200">
                            <div
                                className="h-20 w-20 flex justify-center items-center"
                            >
                                <IoIosAdd
                                    className='text-[3.5rem]'
                                />
                            </div>
                            <p>Add a new plant</p>
                        </div>
                    </div>
                </>
            }
        </div>
        <div className='pb-1' />
    </motion.div>
}

export default PlantDrawer