/* eslint-disable no-unused-vars */
/* eslint-disable react/prop-types */
// import PlantCard from "./PlantCard"
import { motion } from "framer-motion"
import React, { use } from "react";
import PlantAddCard from "./PlantAddCard";
import SliderContainer from "./SliderContainer";
import { FaChevronDown, FaChevronUp } from "react-icons/fa";
import { IoClose } from "react-icons/io5"
import { useEffect, useState } from "react";

function PredictionDrawer({
    latitude,
    longitude,
    setUserPlants,
    soilAndWeatherProperties,
    isPredictionsShowing,
    setPredictionsShowing,
    isPredictionsLoading,
    predictions,
    handleRepredict,
    ignoreNPK, setIgnoreNPK,
    locationHasSoil
}) {

    const [isFullHeight, setIsFullHeight] = useState(window.innerWidth < 1024);

    useEffect(() => {
        const handleResize = () => {
            // Only update state if breakpoint changes (avoids unnecessary re-renders)
            setIsFullHeight(window.innerWidth < 1024);
        };

        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, []);

    return (
        <motion.div
            initial={{}}
            // This may not be great. Framer motion now controls the height instead of tailwind
            // This now shows a different number of cards depending on screen size
            animate={{ height: isPredictionsShowing ? (isFullHeight ? "100%" : "95%") : "0%" }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className={`pt-2 z-[108] md:right-2 bottom-0 sm:bottom-2 sm:top-1/2 sm:-translate-y-1/2 overflow-y-hidden fixed w-full lg:max-w-110 md:max-w-1/2 ${isPredictionsShowing ? "h-screen" : "hidden"} flex flex-col bg-neutral-950/[0.85] rounded-t-2xl items-center backdrop-blur-lg no-scrollbar sm:rounded-b-2xl md:max-w-2/5 shadow-xl`}
        >

            <div
                className="h-10 w-full flex items-center text-white/[0.3] hover:text-white/[0.6] transition duration-200 cursor-pointer"
                onClick={() => setPredictionsShowing(false)}
            >
                <div
                    className="h-10 w-10 flex justify-center items-center mx-2"
                >
                    <IoClose
                        className="text-[1.8rem]"
                    />
                </div>
                <p>Close Predictions</p>
            </div>
            <div className="w-full border border-white/[0.1] mt-2"></div>
            {isPredictionsLoading ?
                <div className="h-full w-full flex items-center justify-center">
                    <span className="loading loading-infinity loading-xl"></span>
                </div>
                :
                !locationHasSoil ?
                    <div className="h-full w-4/5 max-w-100 text-center flex items-center justify-center">
                        <p className="text-green-500 text-xl">No Soil Data for your Location. Please use Add Plant instead</p>
                        {/* <span className="loading loading-infinity loading-xl"></span> */}
                    </div>
                    :

                    <>
                        <div className="overflow-y-scroll no-scrollbar w-full flex flex-col items-center">
                            {/* Slider Container */}
                            <SliderContainer
                                soilAndWeatherProperties={soilAndWeatherProperties}
                                ignoreNPK={ignoreNPK}
                            />
                            <div className="w-full border border-white/[0.1] mb-2"></div>
                            {/* Plant Cards */}

                            {
                                predictions.map((prediction, index) => {

                                    return <React.Fragment key={index}>
                                        <PlantAddCard
                                            latitude={latitude}
                                            longitude={longitude}
                                            setUserPlants={setUserPlants}
                                            {...prediction}
                                        />
                                        <div className="w-9/10 max-w-100 border border-white/[0.1] mb-1 mt-3"></div>
                                    </React.Fragment>
                                })
                            }
                        </div>
                        <div className="w-full border border-white/[0.1]" />
                        <div className="min-h-16 max-h-18  w-full max-w-110 flex justify-center">
                            <div className="min-w-24"></div>
                            <button
                                className="cursor-pointer min-w-52 flex items-center justify-center border-2 border-white/[0.1] hover:border-white/[0.3] transition duration-200 rounded-xl my-2"
                                onClick={handleRepredict}
                            >
                                Predict Again
                            </button>
                            <div
                                className="min-w-24  flex flex-col items-center justify-around py-2 cursor-pointer"
                            >
                                <p className={`text-sm transition duration-200 ${ignoreNPK ? "" : "text-white/[0.3]"}`}>Ignore NPK</p>
                                <input
                                    type="checkbox"
                                    className="toggle border-none bg-white/[0.2] text-white/[0.4] checked:bg-white/[0.6] checked:text-white/[0.8]"
                                    checked={ignoreNPK}
                                    onChange={((e) => setIgnoreNPK(e.target.checked))}
                                />
                            </div>
                        </div>
                    </>
            }
        </motion.div>
    )
}

export default PredictionDrawer
