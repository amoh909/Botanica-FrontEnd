import "weather-icons/css/weather-icons.css"
const WeatherIcon = ({
    condition
    }) => {
    const conditionToIcon = {
        clear_sky: "wi-day-sunny",
        mainly_clear: "wi-day-cloudy pt-1",
        partly_cloudy: "wi-day-cloudy pt-1",
        overcast: "wi-cloudy",
        fog: "wi-fog",
        depositing_rime_fog: "wi-fog",
        light_drizzle: "wi-sprinkle",
        moderate_drizzle: "wi-sprinkle",
        heavy_drizzle: "wi-rain",
        light_rain: "wi-rain",
        moderate_rain: "wi-rain",
        heavy_rain: "wi-rain",
        light_freezing_rain: "wi-rain-mix",
        heavy_freezing_rain: "wi-rain-mix",
        light_snow: "wi-snow",
        moderate_snow: "wi-snow",
        heavy_snow: "wi-snow",
        snow_grains: "wi-snow",
        light_rain_shower: "wi-showers",
        moderate_rain_shower: "wi-showers",
        heavy_rain_shower: "wi-showers",
        light_snow_shower: "wi-snow-wind",
        heavy_snow_shower: "wi-snow-wind",
        thunderstorm: "wi-thunderstorm",
        thunderstorm_with_light_hail: "wi-thunderstorm",
        thunderstorm_with_heavy_hail: "wi-thunderstorm",
    }
    const iconClass = conditionToIcon[condition] || "wi-day-sunny"

    return <i className={`wi text-2xl ${iconClass}`}/>;
}
export default WeatherIcon