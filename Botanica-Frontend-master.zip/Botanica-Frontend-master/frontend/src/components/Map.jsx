/* eslint-disable react/prop-types */
/* eslint-disable no-unused-vars */
import mapboxgl from "mapbox-gl"
import { useRef, useEffect, useState } from "react"
import { useLocationContext } from "../contexts/LocationContext"

mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_API_KEY
mapboxgl.setRTLTextPlugin(
    'https://api.mapbox.com/mapbox-gl-js/plugins/mapbox-gl-rtl-text/v0.2.3/mapbox-gl-rtl-text.js',
    null,
    true // Lazy load the plugin
);//fixes arabic text

function Map({
    latitude, setLatitude,
    longitude, setLongitude,
    mapRef, setMap
}) {

    const marker = new mapboxgl.Marker({
        color: '#335533',
        scale: 0.8
    })
    marker._element.id = 'marker'
    const removeMarker = () => {
        if (document.getElementById('marker'))
            document.getElementById('marker').remove()
        marker.remove()
    }

    const { userLatitude, userLongitude, isSharingLocation } = useLocationContext()
    // on load, have the chosen lat/long be the user's current location
    // but still want to allow user to choose another location than his own
    // if he clicks on the live location dot, he chooses his own location and it pulses
    let clickTimeout

    const options = {
        container: "map-container",
        center: [longitude, latitude],
        zoom: 10,
        style: "mapbox://styles/hadizorkot331/cm8ai9tkg00fe01qr3jsp4fcz",
        projection: "mercator",
        minZoom: 3,
        attributionControl: false
    }

    // builds map
    useEffect(() => {
        const map = mapRef.current = new mapboxgl.Map(options)
        setMap(map)

        const addSoilDataSourceAndLayers = () => {
            // adding data sources
            map.addSource('soilgrid-ph', {
                'type': 'raster',
                'tiles': [
                    'https://maps.isric.org/mapserv?map=/map/phh2o.map&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&LAYERS=phh2o_0-5cm_mean&STYLES=&FORMAT=image/png&TRANSPARENT=TRUE&SRS=EPSG:3857&BBOX={bbox-epsg-3857}&WIDTH=64&HEIGHT=64'
                ],
                'tileSize': 64
            });
            map.addSource('soilgrid-nitrogen', {
                'type': 'raster',
                'tiles': [
                    'https://maps.isric.org/mapserv?map=/map/nitrogen.map&SERVICE=WMS&VERSION=1.1.1&REQUEST=GetMap&LAYERS=nitrogen_0-5cm_mean&STYLES=&SRS=EPSG:3857&BBOX={bbox-epsg-3857}&WIDTH=64&HEIGHT=64&FORMAT=image/png'
                ],
                'tileSize': 64
            });

            // adding layers
            map.addLayer(
                {
                    'id': 'soilgrid-ph-layer',
                    'type': 'raster',
                    'source': 'soilgrid-ph',
                    'paint': {}
                },
                "water",
                "road-simple",
                "road-label-simple"
            );
            // map.addLayer(
            //     {
            //         'id': 'soilgrid-nitrogen-layer',
            //         'type': 'raster',
            //         'source': 'soilgrid-nitrogen',
            //         'paint': {}
            //     },
            //     "water",
            //     "road-simple",
            //     "road-label-simple"
            // );
        }

        // takes in properties and creates pulsating dot
        const pulsatingeDot = (size, opacity, r1, g1, b1, r2, g2, b2) => {
            return {
                width: size,
                height: size,
                data: new Uint8Array(size * size * 4),

                onAdd: function () {
                    const canvas = document.createElement('canvas');
                    canvas.width = this.width;
                    canvas.height = this.height;
                    this.context = canvas.getContext('2d');
                },

                render: function () {
                    const duration = 1000;
                    const t = (performance.now() % duration) / duration;

                    const radius = (size / 2) * 0.3;
                    const outerRadius = (size / 2) * 0.7 * t + radius;
                    const context = this.context;

                    context.clearRect(0, 0, this.width, this.height);
                    context.beginPath();
                    context.arc(
                        this.width / 2,
                        this.height / 2,
                        outerRadius,
                        0,
                        Math.PI * 2
                    );
                    context.fillStyle = `rgba(${r1}, ${g1}, ${b1}, ${1 - t})`;
                    context.fill();

                    context.beginPath();
                    context.arc(this.width / 2, this.height / 2, radius, 0, Math.PI * 2);
                    context.fillStyle = `rgba(${r2}, ${g2} , ${b2}, ${opacity})`;
                    context.strokeStyle = 'white';
                    context.lineWidth = 5 - 2 * t;
                    context.fill();
                    context.stroke();

                    this.data = context.getImageData(0, 0, this.width, this.height).data;

                    map.triggerRepaint();

                    return true;
                }
            };
        };
        const semiPulsatingDot = (size, opacity, r1, g1, b1, r2, g2, b2) => {
            return {
                width: size,
                height: size,
                data: new Uint8Array(size * size * 4),

                onAdd: function () {
                    const canvas = document.createElement('canvas');
                    canvas.width = this.width;
                    canvas.height = this.height;
                    this.context = canvas.getContext('2d');
                },

                render: function () {
                    const duration = 1000;
                    const t = (performance.now() % duration) / duration;

                    const radius = (size / 2) * 0.3;
                    const outerRadius = (size / 2) * 0.35 + radius;
                    const context = this.context;

                    context.clearRect(0, 0, this.width, this.height);
                    context.beginPath();
                    context.arc(
                        this.width / 2,
                        this.height / 2,
                        outerRadius,
                        0,
                        Math.PI * 2
                    );
                    context.fillStyle = `rgba(${r1}, ${g1}, ${b1}, ${0.5 * (1 - t)})`;
                    context.fill();

                    context.beginPath();
                    context.arc(this.width / 2, this.height / 2, radius, 0, Math.PI * 2);
                    context.fillStyle = `rgba(${r2}, ${g2} , ${b2}, ${opacity})`;
                    context.strokeStyle = 'white';
                    context.lineWidth = 4.5 - t;
                    context.fill();
                    context.stroke();

                    this.data = context.getImageData(0, 0, this.width, this.height).data;

                    map.triggerRepaint();

                    return true;
                }
            };
        };
        const addImages = () => {
            // use addImage to add custom icons/images to the style
            map.addImage('pulsating-green-dot', pulsatingeDot(90, 1, 100, 100, 100, 80, 200, 80), { pixelRatio: 2 });
            map.addImage('semi-pulsating-green-dot', semiPulsatingDot(90, 1, 100, 100, 100, 80, 200, 80), { pixelRatio: 2 })
        }

        const addLocationSourceAndLayer = () => {
            if (isSharingLocation) {
                // source for user's live location
                map.addSource('user-live-location', {
                    type: 'geojson',
                    data: {
                        type: 'FeatureCollection',
                        features: [{
                            type: 'Feature',
                            geometry: {
                                type: 'Point',
                                coordinates: [userLongitude, userLatitude]
                            },

                        }]
                    }
                })
                // layer for the live location
                map.addLayer({
                    id: 'user-live-location-layer',
                    type: 'symbol',
                    source: 'user-live-location',
                    layout: {
                        'icon-image': 'pulsating-green-dot'
                    }
                })
                // if user clicks on the dot, make it pulse 
                // if user currently has another location chosen, it doesn't pulse
                map.on('click', 'user-live-location-layer', () => {
                    // clear the previous timeout
                    if (clickTimeout) clearTimeout(clickTimeout)
                    setLatitude(userLatitude)
                    setLongitude(userLongitude)
                    removeMarker()
                    map.setLayoutProperty('user-live-location-layer', 'icon-image', 'pulsating-green-dot')
                })
            }
            map.on('click', (e) => {
                // clear the previous timeout
                if (clickTimeout) clearTimeout(clickTimeout)
                // if live location dot was clicked, ignore the click
                const features = map.queryRenderedFeatures(e.point);
                if (features.length && features[0].layer.id == 'user-live-location-layer') return
                // set a new timeout
                // eslint-disable-next-line react-hooks/exhaustive-deps
                clickTimeout = setTimeout(() => {
                    setLatitude(e.lngLat.lat)
                    setLongitude(e.lngLat.lng)
                    marker.setLngLat(e.lngLat).addTo(map)
                    // live location dot stops pulsating
                    if (map.getLayer('user-live-location-layer')) map.setLayoutProperty('user-live-location-layer', 'icon-image', 'semi-pulsating-green-dot')
                }, 350)
            })
            // make sure it's not a double click
            map.on('zoom', () => {
                if (clickTimeout) clearTimeout(clickTimeout)
            })
        }

        map.once('load', () => {
            addSoilDataSourceAndLayers()
            addImages()
            addLocationSourceAndLayer()
        });
    }, [])

    return < div className="fixed z-10 w-screen h-screen bg-green-400"  >
        <div className="w-full h-full" id="map-container"></div>
    </div >
}

export default Map