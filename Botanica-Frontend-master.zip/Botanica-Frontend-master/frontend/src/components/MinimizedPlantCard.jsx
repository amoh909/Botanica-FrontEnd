/* eslint-disable react/prop-types */
import { IoMdSunny } from "react-icons/io";
import { FiDroplet } from "react-icons/fi";
import { IoIosAdd } from "react-icons/io";
import { AnimatePresence, motion } from "framer-motion";
import { useState } from 'react'
import api from "../api";

const capitalizeFirstLetter = (str) => {
    return str.charAt(0).toUpperCase() + str.slice(1);
}

function MinimizedPlantCard({
    latitude,
    longitude,
    name, watering, sunlight,
    indoor, cycle, min_hardiness, max_hardiness, id,
    watering_avg_volume_requirement,
    setUserPlants, setAddingPlant
}) {

    async function handleAddPlant() {
        const response = await api.post("/crops/", { "lat": latitude.toFixed(8), "lon": longitude.toFixed(8), "prediction_probability": 100, "crop_id": id })
        if (response.status == 201) {
            setUserPlants(prev => [response.data, ...prev])
            setAddingPlant(false)
        } else {
            console.log(response)
            alert("Something went wrong")
        }
    }

    const [showDetail, setShowDetail] = useState(false);
    return (
        <div onClick={() => setShowDetail(!showDetail)} className="w-full z-50 max-w-110 h-auto flex flex-col items-center justify-center px-3 py-1">
            <div className="w-full h-auto flex flex-row items-center justify-between px-2">
                <div className="flex w-full flex-row h-10 justify-between items-center ">
                    {/* Name, Watering, Sun... */}
                    <div className="w-auto h-full flex flex-row justify-between items-center cursor-pointer">
                        {/* Name */}
                        <p className="pl-1 text-2xl text-white">{capitalizeFirstLetter(name)}</p>
                    </div>
                    <div className="flex gap-2">
                        <div className="flex justify-between items-center">
                            {/* Watering and Sun */}
                            <div className="flex">
                                <div className="w-20 flex flex-row gap-1.5 items-center mr-4">
                                    <FiDroplet className="text-blue-500" />
                                    <p className="text-sm text-slate-100">{capitalizeFirstLetter(watering)}</p>
                                </div>
                                <div className="w-14 flex flex-row gap-1.5 items-center">
                                    <IoMdSunny className="text-yellow-500" />
                                    <p className="text-sm text-slate-100">{capitalizeFirstLetter(sunlight.split("_")[0])}</p>
                                </div>
                            </div>
                        </div>
                        <div
                            className="flex justify-center items-center cursor-pointer text-white/[0.3] hover:text-white/[0.6] transition duration-200"
                        >
                            <IoIosAdd className="text-4xl" onClick={handleAddPlant} />
                        </div>
                    </div>
                </div>
            </div>
            <AnimatePresence>
                {showDetail &&
                    <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3, ease: "easeInOut" }}
                        className="w-full h-auto flex flex-row justify-between px-3"
                    >
                        <div className="flex-row w-full flex h-auto">
                            <div className="w-1/2 flex flex-col justify-center gap-2 py-2 px-1">
                                <p><span className="font-semibold">Placement:</span> {indoor ? "Indoors" : "Outdoors"}</p>
                                <p><span className="font-semibold">Cycle:</span> {capitalizeFirstLetter(cycle)}</p>
                            </div>
                            <div className="w-1/2 flex flex-col justify-center gap-2 py-2 px-1">
                                <p><span className="font-semibold">Watering vol:</span> {watering_avg_volume_requirement} L/m<sup>2</sup></p>
                                <p><span className="font-semibold">Hardiness:</span> {min_hardiness}-{max_hardiness}</p>
                            </div>

                        </div>
                    </motion.div>
                }
            </AnimatePresence>
        </div>
    )
}

export default MinimizedPlantCard