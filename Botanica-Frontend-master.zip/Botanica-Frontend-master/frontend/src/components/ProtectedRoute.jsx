import api from "../api.js";
import { useState, useEffect } from "react"
import { Navigate } from "react-router-dom";
import { jwtDecode } from "jwt-decode";

// eslint-disable-next-line react/prop-types
function ProtectedRoute({ children }) {
    const [isAuthenticated, setIsAuthenticated] = useState(false)
    const [isLoading, setIsLoading] = useState(true)

    const auth = async () => {
        const token = localStorage.getItem("access")

        if (!token) {
            setIsAuthenticated(false)
            return;
        }

        const decodedToken = jwtDecode(token, { header: false })
        const expirationDate = decodedToken.exp

        if ((Date.now() / 1000) > expirationDate) {
            await refresh()
        } else {
            setIsAuthenticated(true);
        }
    }

    const refresh = async () => {
        try {
            const refreshToken = localStorage.getItem("refresh")
            const accessToken = localStorage.getItem("access")

            if (!refreshToken) {
                setIsAuthenticated(false);
                return;
            }

            const response = await api.post("/auth/refresh/", {
                refresh: refreshToken,
                access: accessToken
            })

            if (response.status == 200) {
                localStorage.setItem("access", response.data.access);
                setIsAuthenticated(true);
                return;
            } else {
                console.log("HERE")
                setIsAuthenticated(false);
                return
            }
        } catch (error) {
            console.log(error)
            setIsAuthenticated(false)
            return
        }
    }

    useEffect(() => {
        auth().catch(() => {
            setIsAuthenticated(false)
        })
        setIsLoading(false)
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [])

    if (isLoading) {
        return <h1>Loading...</h1>
    }

    return isAuthenticated ? children : <Navigate to="/login" />

}

export default ProtectedRoute