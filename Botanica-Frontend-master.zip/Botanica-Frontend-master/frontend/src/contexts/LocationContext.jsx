/* eslint-disable react/prop-types */
import { createContext, useContext, useState, useEffect } from "react";


const LocationContext = createContext()

// eslint-disable-next-line react-refresh/only-export-components
export const useLocationContext = () => { return useContext(LocationContext) }

export function LocationProvider({ children }) {
    const [userLatitude, setUserLatitude] = useState(null)
    const [userLongitude, setUserLongitude] = useState(null)
    const [userLocationLoading, setUserLocationLoading] = useState(true)
    const [isSharingLocation, setSharingLocation] = useState(false)

    const getUserLocation = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                setUserLatitude(position.coords.latitude)
                setUserLongitude(position.coords.longitude)
                setUserLocationLoading(false)
                setSharingLocation(true)
            }, () => {
                console.log("User Refused Location Permissions")
                setUserLocationLoading(false)
            })
        } else {
            console.log("No navigator found")
            setUserLocationLoading(false)
        }
    }

    useEffect(() => {
        // NOTE: comment this line and uncomment the next if there is no soil data for your location
        getUserLocation()
        // setLocationLoading(false)
    }, [])

    if (userLocationLoading) {
        return <div className="w-screen h-screen bg-neutral-800 flex justify-center items-center">
            <div className="flex flex-col gap-2 justify-center items-center">
                <h1 className="text-3xl text-green-500">Getting your location...</h1>
                <span className="loading loading-infinity loading-xl"></span>
            </div>
        </div>
    }

    return <LocationContext.Provider value={{
        userLatitude: userLatitude,
        userLongitude: userLongitude,
        isSharingLocation: isSharingLocation
    }}>
        {children}
    </LocationContext.Provider>
}
