import { useEffect, useState } from 'react'
import LoginForm from '../components/LoginForm'
import RegisterForm from '../components/RegisterForm';
function LoginPage() {
    useEffect(() => {
        document.body.style.overflow = "hidden";

        return () => document.body.style.overflow = "auto";
    }, [])
    const [isRegistering, setRegistering] = useState(false)
    return (
        <div className="w-screen h-screen flex justify-center items-center overflow-y-hidden">
            <h1 className="hidden bg-neutral h-screen w-1/2 text-green-600 font-sans text-7xl md:flex items-center justify-center">
                <div className="text-left font-extrabold  hover:text-8xl transition-all duration-200">
                    SUCCESS <br /> STARTS <br /> HERE.
                </div>
            </h1>
            <div className="w-2/9 h-[120vh] rotate-6 bg-green-600 absolute left-20/44 pb-10"></div>
            <div className="w-screen h-screen md:w-1/2 font-sans bg-green-600 flex items-center justify-center">
                {
                isRegistering ?
                <RegisterForm
                setRegistering = {setRegistering}
                />
                :
                <LoginForm
                setRegistering = {setRegistering}
                />
                }   
            </div>
        </div>
    )

}

export default LoginPage