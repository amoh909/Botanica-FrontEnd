/* eslint-disable no-unused-vars */
import PlantDrawer from "../components/PlantDrawer"
import PredictionDrawer from "../components/PredictionDrawer";
import api from "../api"
import TopBar from "../components/TopBar"
import { TbShovel } from "react-icons/tb";
import { useState, useEffect, useRef } from "react"
import { AnimatePresence, motion } from "framer-motion";
import Map from "../components/Map";
import { useLocationContext } from "../contexts/LocationContext";

function Home() {

    // plant drawer states
    const [expanded, setExpanded] = useState(false);
    const [isSmallScreen, setIsSmallScreen] = useState(window.innerWidth <= 640);
    const [isAddingPlant, setAddingPlant] = useState(false)

    useEffect(() => {
        const handleResize = () => {
            // Update only if crossing the breakpoint to avoid unnecessary re-renders
            var isSmall = window.innerWidth <= 640
            setIsSmallScreen(isSmall);
            if (isSmall) setAddingPlant(false) // if we transition into small screen, stop adding plant
            else setExpanded(false) // if we transition into big screen, shouldn't be expanded because it's buggy
        };

        window.addEventListener("resize", handleResize);
        return () => window.removeEventListener("resize", handleResize);
    }, []);

    // user plants and all plants
    const [userPlants, setUserPlants] = useState([])
    const [allPlants, setAllPlants] = useState([])
    // fetches all / user's plants from api
    useEffect(() => {
        const fetchEndpoint = async (endpoint, setState) => {
            const response = await api.get(endpoint)
            if (response.status == 200) {
                setState(response.data)
            }
        }
        fetchEndpoint("/crops/all-crops", setAllPlants)
        fetchEndpoint("/crops/", setUserPlants)
    }, [])

    // map related variables
    // might need access to map somewhere else so it's a state here for now
    const mapRef = useRef()
    const [map, setMap] = useState(mapRef.current)
    // userLatitude/userLongitude is the lat long of the user's physical location
    // latitude/longitude, is the lat long currently selected on the map
    const { userLatitude, userLongitude, isSharingLocation } = useLocationContext()
    const [latitude, setLatitude] = useState(isSharingLocation ? userLatitude : 35.5431)
    const [longitude, setLongitude] = useState(isSharingLocation ? userLongitude : 34.2341)

    // prediction related states
    const [nitrogen, setNitrogen] = useState(null)
    const [phosphorus, setPhosphorus] = useState(null)
    const [potassium, setPotassium] = useState(null)
    const [temperature, setTemperature] = useState(null)
    const [humidity, setHumidity] = useState(null)
    const [ph, setPh] = useState(null)
    const [rainfall, setRainfall] = useState(null)
    const [ignoreNPK, setIgnoreNPK] = useState(false)
    const [locationHasSoil, setLocationHasSoil] = useState(true)

    const [isPredictionsShowing, setPredictionsShowing] = useState(false)
    const [predictions, setPredictions] = useState([])
    const [isPredictionsLoading, setIsPredictionsLoading] = useState(true)

    const fetchPredictions = async () => {
        const response = await api.post("/model/predict/", { lat: latitude.toFixed(8), long: longitude.toFixed(8), useNPK: !ignoreNPK })

        if (response.status == 200) {
            // TODO: Fix rounding issues
            setLocationHasSoil(true)

            const featureData = response.data.feature_data
            setNitrogen(Math.round(featureData["N"]))
            setPhosphorus(Math.round(featureData["P"]))
            setPotassium(Math.round(featureData["K"]))
            setTemperature(Math.round(featureData["temperature"]))
            setHumidity(Math.round(featureData["humidity"]))
            setPh(Math.round(featureData["ph"]))
            setRainfall(Math.round(featureData["rainfall"]))

            setPredictions(response.data.predictions)
        } else {
            if (response.data == "No Soil / Weather Data OR Bad Data found for this location") {
                setLocationHasSoil(false)
            } else {
                alert("An error occured")
            }
            console.log(response)
        }
    }

    const handlePredict = async () => {
        setPredictionsShowing(true)
        setIsPredictionsLoading(true)
        if (predictions.length == 0) {
            await fetchPredictions()
        }
        setIsPredictionsLoading(false)
    }

    const handleRepredict = async () => {
        setIsPredictionsLoading(true)
        setPredictions([])
        await fetchPredictions()
        setIsPredictionsLoading(false)
    }

    return (
        <div className="w-screen flex justify-center flex-row h-screen">
            <Map
                latitude={latitude}
                setLatitude={setLatitude}
                longitude={longitude}
                setLongitude={setLongitude}
                mapRef={mapRef}
                setMap={setMap}
            />
            {/* Makes button and topbar fade away when plantdrawer is expanded on mobile */}
            <AnimatePresence>
                {!(isSmallScreen && expanded) &&
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="contents" // makes it act like a fragment
                    >
                        {/* Plant button */}
                        <button
                            className="flex z-20 flex-row justify-center items-center gap-2 absolute bottom-2/7 sm:bottom-3 left-1/2 sm:left-2 sm:translate-x-1 sm:w-110 rounded-3xl sm:rounded-2xl w-4/10 h-1/12 -translate-x-1/2 bg-neutral-950/[0.85] hover:bg-neutral-950/[0.9] transition duration-200 backdrop-blur-lg sm:text-2xl cursor-pointer shadow-xl"
                            onClick={handlePredict}
                        >
                            <p className="text-lg text-slate-100 font-semibold">
                                Plant
                            </p>
                            <TbShovel className="text-xl text-green-500" />
                        </button>
                        <TopBar
                            temperature={17}
                            humidity={71}
                            location_name='Damour'
                            latitude={latitude}
                            longitude={longitude}
                        />
                    </motion.div>
                }
            </AnimatePresence>
            <PlantDrawer
                expanded={expanded}
                setExpanded={setExpanded}
                isSmallScreen={isSmallScreen}
                isAddingPlant={isAddingPlant}
                setAddingPlant={setAddingPlant}
                latitude={latitude}
                longitude={longitude}
                userPlants={userPlants}
                setUserPlants={setUserPlants}
                allPlants={allPlants}
            />
            <PredictionDrawer
                latitude={latitude}
                longitude={longitude}
                setUserPlants={setUserPlants}
                predictions={predictions}
                isPredictionsLoading={isPredictionsLoading}
                handleRepredict={handleRepredict}
                locationHasSoil={locationHasSoil}
                soilAndWeatherProperties={
                    {
                        N: {
                            value: nitrogen,
                            setter: setNitrogen
                        },
                        P: {
                            value: phosphorus,
                            setter: setPhosphorus
                        },
                        K: {
                            value: potassium,
                            setter: setPotassium
                        },
                        temp: {
                            value: temperature,
                            setter: setTemperature
                        },
                        humid: {
                            value: humidity,
                            setter: setHumidity
                        },
                        PH: {
                            value: ph,
                            setter: setPh
                        },
                        rain: {
                            value: rainfall,
                            setter: setRainfall
                        }
                    }
                }
                isPredictionsShowing={isPredictionsShowing}
                setPredictionsShowing={setPredictionsShowing}
                ignoreNPK={ignoreNPK}
                setIgnoreNPK={setIgnoreNPK}
            />
        </div>
    )
}

export default Home